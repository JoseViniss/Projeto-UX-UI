// AVL Control — protótipo com dados em memória e autenticação simulada.
// Carregado ao final do body, após Tailwind e Chart.js.

tailwind.config = {
    theme: {
        extend: {
            colors: {
                brand: {
                    dark: '#0F172A',
                    navy: '#1E3A8A',
                    blue: '#2563EB',
                    lightBlue: '#EFF6FF',
                    green: '#059669',
                    emerald: '#10B981',
                    lightGreen: '#ECFDF5',
                    accent: '#3B82F6',
                }
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            }
        }
    }
}

// Referências dos Gráficos Chart.js
let chartFrotaStatus = null;
let chartCustosObra = null;
let chartConsumoMes = null;

// ESTADO GLOBAL COMPLETO EM MEMÓRIA
const state = {
    activeRole: 'locadora', // 'locadora' ou 'locatario'
    activeTab: 'dashboard',
    selectedFilterStatus: 'todos',
    selectedFilterFinancTipo: 'todos',

    obras: [
        { id: 1, nome: "Edifício Horizon Lux", gestor: "Eng. Ricardo Alves", local: "São Paulo - SP", status: "Ativa" },
        { id: 2, nome: "Rodovia BR-101 Trecho Sul", gestor: "Eng. Mariana Costa", local: "Santos - SP", status: "Ativa" },
        { id: 3, nome: "Parque Eólico Serra Verde", gestor: "Carlos Mendes", local: "Caetité - BA", status: "Em Início" }
    ],

    motoristas: [
        { id: 1, nome: "João Silva", cnh: "Categoria E", cnhVencimento: "2026-11-15", obraId: 1, telefone: "(11) 98765-4321" },
        { id: 2, nome: "Marcos Oliveira", cnh: "Categoria D", cnhVencimento: "2026-10-05", obraId: 2, telefone: "(13) 99123-8877" },
        { id: 3, nome: "Antônio Santos", cnh: "Categoria C", cnhVencimento: "2027-04-20", obraId: 1, telefone: "(11) 97711-2233" }
    ],

    veiculos: [
        { id: 1, placa: "ABC-8899", modelo: "Volvo FMX 500 Basculante", categoria: "Caminhão", km: 68400, obraId: 1, status: "Em Obra", valorMensal: 12500, docStatus: "Ok" },
        { id: 2, placa: "KRH-4120", modelo: "Caterpillar 426F2 Retroescavadeira", categoria: "Maquinário", km: 3200, obraId: 2, status: "Em Obra", valorMensal: 9800, docStatus: "Atencao" },
        { id: 3, placa: "GXX-9011", modelo: "Toyota Hilux CD 4x4", categoria: "Pickup 4x4", km: 42100, obraId: 1, status: "Disponível", valorMensal: 5400, docStatus: "Ok" },
        { id: 4, placa: "RST-5A12", modelo: "Mercedes-Benz Atego 2730", categoria: "Caminhão", km: 112000, obraId: 2, status: "Manutenção", valorMensal: 11000, docStatus: "Vencido" }
    ],

    financeiro: [
        { id: 1, tipo: "Combustível", veiculoId: 1, data: "2026-10-20", litros: 180, valor: 1080.00, km: 68200, motorista: "João Silva", obraId: 1 },
        { id: 2, tipo: "Pedágio", veiculoId: 3, data: "2026-10-21", litros: 0, valor: 45.50, km: 42000, motorista: "Antônio Santos", obraId: 1 },
        { id: 3, tipo: "Combustível", veiculoId: 2, data: "2026-10-18", litros: 120, valor: 744.00, km: 3180, motorista: "Marcos Oliveira", obraId: 2 },
        { id: 4, tipo: "Peças / Insumos", veiculoId: 4, data: "2026-10-15", litros: 0, valor: 850.00, km: 111500, motorista: "Marcos Oliveira", obraId: 2 }
    ],

    manutencoes: [
        { id: 1, veiculoId: 4, tipo: "Corretiva", descricao: "Troca do sistema de embreagem e alinhamento do eito traseiro", data: "2026-10-22", status: "Em Andamento", custo: 3200.00 },
        { id: 2, veiculoId: 2, tipo: "Preventiva", descricao: "Troca de óleo hidráulico e filtros gerais aos 3.300h", data: "2026-10-28", status: "Agendada", custo: 1450.00 }
    ],

    canhotos: [
        { id: 1, veiculoId: 1, tipo: "Entrega na Obra", data: "2026-09-01", status: "Aprovado", arquivo: "canhoto_volvo_horizon.pdf", obs: "Recebido pelo Eng. Ricardo sem ressalvas." },
        { id: 2, veiculoId: 2, tipo: "Checklist de Inspeção", data: "2026-09-15", status: "Pendente Validar", arquivo: "checklist_cat_426.jpg", obs: "Pequeno arranhão na caçamba lateral direita." }
    ],

    documentosRegulação: [
        { id: 1, titulo: "IPVA 2026 - Volvo FMX", veiculoId: 1, tipo: "Imposto", vencimento: "2026-11-20", status: "Ok" },
        { id: 2, titulo: "Seguro Frota - Cat Retroescavadeira", veiculoId: 2, tipo: "Seguro", vencimento: "2026-11-02", status: "Atencao" },
        { id: 3, titulo: "Licenciamento - Mercedes Atego", veiculoId: 4, tipo: "Licenciamento", vencimento: "2026-10-10", status: "Vencido" }
    ]
};

// ==========================================
// AUTENTICAÇÃO E LOGIN
// ==========================================
let tempLoginRole = 'locadora';

function setLoginRole(role) {
    tempLoginRole = role;
    const btnLocadora = document.getElementById('login-role-locadora');
    const btnLocatario = document.getElementById('login-role-locatario');

    if(role === 'locadora') {
        btnLocadora.className = "py-2 px-3 text-xs font-bold rounded-xl transition bg-brand-blue text-white shadow-sm flex items-center justify-center gap-1.5";
        btnLocatario.className = "py-2 px-3 text-xs font-bold rounded-xl transition text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5";
    } else {
        btnLocatario.className = "py-2 px-3 text-xs font-bold rounded-xl transition bg-brand-green text-white shadow-sm flex items-center justify-center gap-1.5";
        btnLocadora.className = "py-2 px-3 text-xs font-bold rounded-xl transition text-slate-600 hover:text-slate-900 flex items-center justify-center gap-1.5";
    }
}

function handleLogin(e) {
    e.preventDefault();
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app-container').classList.remove('hidden');

    switchRole(tempLoginRole);
    populateSelectOptions();
    navigate('dashboard');
    showToast('Bem-vindo ao AVL Control!');
}

function handleLogout() {
    document.getElementById('app-container').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
    showToast('Sessão encerrada com sucesso');
}

// ==========================================
// INICIALIZAÇÃO DE SELECTS
// ==========================================
function populateSelectOptions() {
    const selectObraModal = document.getElementById('v-obra');
    const selectObraMotorista = document.getElementById('m-obra');
    const selectVeiculoFinanc = document.getElementById('f-veiculo');
    const selectMotoristaFinanc = document.getElementById('f-motorista');
    const selectVeiculoManut = document.getElementById('m-veiculo');
    const selectVeiculoCanhoto = document.getElementById('c-veiculo');

    if (selectObraModal) {
        selectObraModal.innerHTML = `<option value="0">Nenhuma (Pátio/Disponível)</option>` + 
            state.obras.map(o => `<option value="${o.id}">${o.nome}</option>`).join('');
    }
    if (selectObraMotorista) {
        selectObraMotorista.innerHTML = state.obras.map(o => `<option value="${o.id}">${o.nome}</option>`).join('');
    }
    if (selectVeiculoFinanc) {
        selectVeiculoFinanc.innerHTML = state.veiculos.map(v => `<option value="${v.id}">${v.placa} - ${v.modelo}</option>`).join('');
    }
    if (selectMotoristaFinanc) {
        selectMotoristaFinanc.innerHTML = state.motoristas.map(m => `<option value="${m.nome}">${m.nome} (${m.cnh})</option>`).join('');
    }
    if (selectVeiculoManut) {
        selectVeiculoManut.innerHTML = state.veiculos.map(v => `<option value="${v.id}">${v.placa} - ${v.modelo}</option>`).join('');
    }
    if (selectVeiculoCanhoto) {
        selectVeiculoCanhoto.innerHTML = state.veiculos.map(v => `<option value="${v.id}">${v.placa} - ${v.modelo}</option>`).join('');
    }
}

function navigate(tabId, filterStatus = 'todos') {
    state.activeTab = tabId;
    state.selectedFilterStatus = filterStatus;

    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('text-brand-blue', 'font-bold');
        btn.classList.add('text-slate-500');
    });
    const activeNav = document.getElementById(`nav-${tabId}`);
    if (activeNav) {
        activeNav.classList.remove('text-slate-500');
        activeNav.classList.add('text-brand-blue', 'font-bold');
    }

    render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function switchRole(role) {
    state.activeRole = role;
    const btnLocadora = document.getElementById('role-locadora');
    const btnLocatario = document.getElementById('role-locatario');
    const bannerText = document.getElementById('role-banner-text');

    if (role === 'locadora') {
        btnLocadora.className = "px-2.5 py-1 text-xs font-semibold rounded-md transition bg-brand-blue text-white shadow-sm";
        btnLocatario.className = "px-2.5 py-1 text-xs font-semibold rounded-md transition text-slate-300 hover:text-white";
        bannerText.innerHTML = `<i class="fa-solid fa-building-flag text-emerald-600"></i> Visão Locadora: Controle Global da Frota e Faturamento`;
    } else {
        btnLocatario.className = "px-2.5 py-1 text-xs font-semibold rounded-md transition bg-brand-green text-white shadow-sm";
        btnLocadora.className = "px-2.5 py-1 text-xs font-semibold rounded-md transition text-slate-300 hover:text-white";
        bannerText.innerHTML = `<i class="fa-solid fa-hard-hat text-brand-blue"></i> Visão Locatário/Obra: Veículos em Operação no Canteiro`;
    }

    render();
}

// ==========================================
// RENDERIZADOR CENTRAL DA SPA
// ==========================================
function render() {
    const container = document.getElementById('main-content');

    switch (state.activeTab) {
        case 'dashboard':
            container.innerHTML = renderDashboard();
            setTimeout(initDashboardCharts, 100);
            break;
        case 'veiculos':
            container.innerHTML = renderVeiculos();
            break;
        case 'obras':
            container.innerHTML = renderObras();
            break;
        case 'financeiro':
            container.innerHTML = renderFinanceiro();
            break;
        case 'manutencao':
            container.innerHTML = renderManutencao();
            break;
        case 'documentos':
            container.innerHTML = renderDocumentos();
            break;
        case 'relatorios':
            container.innerHTML = renderRelatorios();
            setTimeout(initBICharts, 100);
            break;
        default:
            container.innerHTML = renderDashboard();
    }

    renderNotificacoesModal();
}

// ==========================================
// 1. DASHBOARD
// ==========================================
function renderDashboard() {
    const totalVeiculos = state.veiculos.length;
    const emOperacao = state.veiculos.filter(v => v.status === 'Em Obra').length;
    const emManutencao = state.veiculos.filter(v => v.status === 'Manutenção').length;
    const custoLocacaoTotal = state.veiculos.reduce((acc, v) => acc + v.valorMensal, 0);

    return `
        <div class="space-y-4 animate-fade-in">

            <!-- Banner de Boas-Vindas -->
            <div class="bg-gradient-to-r from-brand-navy via-blue-900 to-slate-900 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
                <div class="relative z-10">
                    <span class="text-[10px] bg-emerald-500/30 text-emerald-300 px-2.5 py-0.5 rounded-full font-bold border border-emerald-400/20 uppercase tracking-wider">Painel Executivo</span>
                    <h2 class="text-xl font-black mt-1">Status da Operação</h2>
                    <p class="text-xs text-blue-200 mt-0.5">Visão consolidada de veículos, custos e obras.</p>
                </div>
                <i class="fa-solid fa-chart-line absolute right-2 bottom-1 text-white/10 text-7xl pointer-events-none"></i>
            </div>

            <!-- CARDS KPIS COM LINKS DIRETO PARA MÓDULOS -->
            <div class="grid grid-cols-2 gap-3">

                <div onclick="navigate('veiculos', 'todos')" class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer active:scale-98 flex items-center space-x-3 group">
                    <div class="w-10 h-10 rounded-xl bg-blue-50 text-brand-blue flex items-center justify-center text-lg font-bold group-hover:bg-brand-blue group-hover:text-white transition">
                        <i class="fa-solid fa-truck-front"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-semibold text-slate-500 flex items-center gap-1">Frota Total <i class="fa-solid fa-arrow-right text-[9px] text-slate-300"></i></p>
                        <p class="text-lg font-extrabold text-slate-800">${totalVeiculos} <span class="text-xs font-normal text-slate-400">unid.</span></p>
                    </div>
                </div>

                <div onclick="navigate('veiculos', 'Em Obra')" class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer active:scale-98 flex items-center space-x-3 group">
                    <div class="w-10 h-10 rounded-xl bg-emerald-50 text-brand-green flex items-center justify-center text-lg font-bold group-hover:bg-brand-green group-hover:text-white transition">
                        <i class="fa-solid fa-hard-hat"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-semibold text-slate-500 flex items-center gap-1">Em Obra <i class="fa-solid fa-arrow-right text-[9px] text-slate-300"></i></p>
                        <p class="text-lg font-extrabold text-emerald-600">${emOperacao} <span class="text-xs font-normal text-slate-400">ativos</span></p>
                    </div>
                </div>

                <div onclick="navigate('manutencao')" class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer active:scale-98 flex items-center space-x-3 group">
                    <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg font-bold group-hover:bg-amber-600 group-hover:text-white transition">
                        <i class="fa-solid fa-wrench"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-semibold text-slate-500 flex items-center gap-1">Manutenção <i class="fa-solid fa-arrow-right text-[9px] text-slate-300"></i></p>
                        <p class="text-lg font-extrabold text-amber-600">${emManutencao} <span class="text-xs font-normal text-slate-400">parados</span></p>
                    </div>
                </div>

                <div onclick="navigate('relatorios')" class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer active:scale-98 flex items-center space-x-3 group">
                    <div class="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg font-bold group-hover:bg-indigo-600 group-hover:text-white transition">
                        <i class="fa-solid fa-chart-pie"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-semibold text-slate-500 flex items-center gap-1">Relatórios <i class="fa-solid fa-arrow-right text-[9px] text-slate-300"></i></p>
                        <p class="text-sm font-extrabold text-slate-800">R$ ${(custoLocacaoTotal/1000).toFixed(1)}k <span class="text-[10px] text-slate-400">/mês</span></p>
                    </div>
                </div>

            </div>

            <!-- GRÁFICO RESUMIDO DOUGHNUT -->
            <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <div class="flex justify-between items-center border-b border-slate-100 pb-2">
                    <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                        <i class="fa-solid fa-chart-pie text-brand-blue"></i> Distribuição Operacional
                    </h3>
                    <button onclick="navigate('relatorios')" class="text-[11px] text-brand-blue font-bold hover:underline">Ver BI Completo</button>
                </div>
                <div class="h-48 relative">
                    <canvas id="chartDashFrota"></canvas>
                </div>
            </div>

            <!-- BANNER PENDÊNCIAS -->
            <div onclick="navigate('documentos')" class="bg-gradient-to-r from-red-50 to-amber-50 rounded-2xl p-4 border border-red-200/60 shadow-sm cursor-pointer hover:shadow-md transition flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-xl bg-red-500 text-white flex items-center justify-center font-bold text-lg">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-800">1 Documento Vencido • 1 Revisão Pendente</h4>
                        <p class="text-[11px] text-slate-500">Clique para regularizar no módulo de Documentos/Canhotos</p>
                    </div>
                </div>
                <i class="fa-solid fa-chevron-right text-slate-400 text-sm"></i>
            </div>

        </div>
    `;
}

function initDashboardCharts() {
    const ctx = document.getElementById('chartDashFrota');
    if(!ctx) return;

    if(chartFrotaStatus) chartFrotaStatus.destroy();

    const emObra = state.veiculos.filter(v => v.status === 'Em Obra').length;
    const disponivel = state.veiculos.filter(v => v.status === 'Disponível').length;
    const manutencao = state.veiculos.filter(v => v.status === 'Manutenção').length;

    chartFrotaStatus = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Em Obra', 'Disponível', 'Manutenção'],
            datasets: [{
                data: [emObra, disponivel, manutencao],
                backgroundColor: ['#10B981', '#2563EB', '#F59E0B'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { font: { size: 11, family: 'Inter' } } }
            }
        }
    });
}

// ==========================================
// 2. GESTÃO DE VEÍCULOS (COMPLETO COM EDIT)
// ==========================================
function renderVeiculos() {
    const filter = state.selectedFilterStatus;
    let list = state.veiculos;
    if(filter !== 'todos') {
        list = state.veiculos.filter(v => v.status === filter);
    }

    return `
        <div class="space-y-4 animate-fade-in">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-base font-bold text-slate-800">Frota de Veículos</h2>
                    <p class="text-xs text-slate-500">Gestão e cadastro de máquinas e utilitários</p>
                </div>
                <button onclick="abrirModalVeiculo()" class="bg-brand-blue hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                    <i class="fa-solid fa-plus"></i> Cadastrar
                </button>
            </div>

            <!-- BARRA DE FILTROS DE STATUS -->
            <div class="flex space-x-2 overflow-x-auto no-scrollbar py-1">
                <button onclick="filterVeiculos('todos')" class="px-3 py-1.5 ${filter==='todos'?'bg-brand-navy text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Todos (${state.veiculos.length})</button>
                <button onclick="filterVeiculos('Em Obra')" class="px-3 py-1.5 ${filter==='Em Obra'?'bg-brand-green text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Em Obra (${state.veiculos.filter(v=>v.status==='Em Obra').length})</button>
                <button onclick="filterVeiculos('Disponível')" class="px-3 py-1.5 ${filter==='Disponível'?'bg-brand-blue text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Disponíveis (${state.veiculos.filter(v=>v.status==='Disponível').length})</button>
                <button onclick="filterVeiculos('Manutenção')" class="px-3 py-1.5 ${filter==='Manutenção'?'bg-amber-600 text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Manutenção (${state.veiculos.filter(v=>v.status==='Manutenção').length})</button>
            </div>

            <!-- CARDS DE VEÍCULOS COM AÇÕES -->
            <div class="space-y-3">
                ${list.length === 0 ? `
                    <div class="bg-white p-8 rounded-2xl text-center text-slate-400 border border-slate-200">
                        <i class="fa-solid fa-truck-monster text-3xl mb-2"></i>
                        <p class="text-xs font-medium">Nenhum veículo encontrado neste filtro.</p>
                    </div>
                ` : list.map(v => {
                    const obra = state.obras.find(o => o.id === v.obraId);
                    let statusBg = 'bg-emerald-100 text-emerald-800';
                    if(v.status === 'Disponível') statusBg = 'bg-blue-100 text-blue-800';
                    if(v.status === 'Manutenção') statusBg = 'bg-amber-100 text-amber-800';

                    return `
                        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3 hover:border-brand-blue/30 transition">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="flex items-center gap-2">
                                        <span class="bg-slate-800 text-white text-[10px] font-mono px-2 py-0.5 rounded font-bold">${v.placa}</span>
                                        <span class="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">${v.categoria}</span>
                                    </div>
                                    <h3 class="font-bold text-slate-800 text-sm mt-1.5">${v.modelo}</h3>
                                </div>
                                <span class="${statusBg} text-[10px] font-bold px-2.5 py-1 rounded-full">${v.status}</span>
                            </div>

                            <div class="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                                <div>
                                    <span class="text-slate-400 text-[10px] block">Alocação Atual</span>
                                    <span class="font-semibold text-slate-700 truncate block">${obra ? obra.nome : 'Pátio Central'}</span>
                                </div>
                                <div>
                                    <span class="text-slate-400 text-[10px] block">Odômetro/Horímetro</span>
                                    <span class="font-bold text-slate-800 font-mono">${v.km.toLocaleString()} KM/h</span>
                                </div>
                            </div>

                            <div class="flex justify-between items-center text-xs pt-1 border-t border-slate-100">
                                <span class="font-extrabold text-brand-navy">R$ ${v.valorMensal.toLocaleString('pt-BR')}<span class="text-[10px] text-slate-400 font-normal">/mês</span></span>
                                <div class="flex gap-2">
                                    <button onclick="abrirModalVeiculo(${v.id})" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] rounded-lg transition flex items-center gap-1">
                                        <i class="fa-solid fa-pen-to-square text-brand-blue"></i> Editar
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function filterVeiculos(status) {
    state.selectedFilterStatus = status;
    render();
}

function abrirModalVeiculo(veiculoId = null) {
    populateSelectOptions();
    const modal = document.getElementById('modal-veiculo');
    const title = document.getElementById('modal-veiculo-title');

    if(veiculoId) {
        const v = state.veiculos.find(x => x.id === veiculoId);
        if(!v) return;
        title.innerHTML = `<i class="fa-solid fa-pen-to-square text-brand-blue"></i> Editar Veículo (${v.placa})`;
        document.getElementById('v-id').value = v.id;
        document.getElementById('v-modelo').value = v.modelo;
        document.getElementById('v-placa').value = v.placa;
        document.getElementById('v-categoria').value = v.categoria;
        document.getElementById('v-km').value = v.km;
        document.getElementById('v-status').value = v.status;
        document.getElementById('v-obra').value = v.obraId;
        document.getElementById('v-valor').value = v.valorMensal;
    } else {
        title.innerHTML = `<i class="fa-solid fa-truck-front text-brand-blue"></i> Cadastrar Novo Veículo`;
        document.getElementById('form-veiculo').reset();
        document.getElementById('v-id').value = '';
    }

    modal.classList.remove('hidden');
}

function handleSalvarVeiculo(e) {
    e.preventDefault();
    const id = document.getElementById('v-id').value;
    const modelo = document.getElementById('v-modelo').value;
    const placa = document.getElementById('v-placa').value.toUpperCase();
    const categoria = document.getElementById('v-categoria').value;
    const km = parseInt(document.getElementById('v-km').value);
    const status = document.getElementById('v-status').value;
    const obraId = parseInt(document.getElementById('v-obra').value);
    const valorMensal = parseFloat(document.getElementById('v-valor').value);

    if(id) {
        const v = state.veiculos.find(x => x.id === parseInt(id));
        if(v) {
            v.modelo = modelo;
            v.placa = placa;
            v.categoria = categoria;
            v.km = km;
            v.status = status;
            v.obraId = obraId;
            v.valorMensal = valorMensal;
            showToast(`Veículo ${placa} atualizado com sucesso!`);
        }
    } else {
        state.veiculos.push({
            id: state.veiculos.length + 1,
            placa, modelo, categoria, km, obraId, status, valorMensal, docStatus: 'Ok'
        });
        showToast(`Novo veículo ${placa} cadastrado!`);
    }

    populateSelectOptions();
    closeModal('modal-veiculo');
    render();
}

// ==========================================
// 3. OBRAS & MOTORISTAS (COMPLETO)
// ==========================================
function renderObras() {
    return `
        <div class="space-y-5 animate-fade-in">

            <!-- SESSÃO DE OBRAS -->
            <div class="space-y-3">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-base font-bold text-slate-800">Obras & Canteiros</h2>
                        <p class="text-xs text-slate-500">Locais ativas de alocação da frota</p>
                    </div>
                    <button onclick="openModal('modal-nova-obra')" class="bg-brand-green hover:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                        <i class="fa-solid fa-plus"></i> Nova Obra
                    </button>
                </div>

                <div class="space-y-3">
                    ${state.obras.map(o => {
                        const veiculosAlocados = state.veiculos.filter(v => v.obraId === o.id);
                        return `
                            <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="font-bold text-slate-800 text-sm">${o.nome}</h3>
                                        <p class="text-xs text-slate-500 mt-0.5"><i class="fa-solid fa-location-dot text-red-500"></i> ${o.local}</p>
                                    </div>
                                    <span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full">${o.status}</span>
                                </div>

                                <div class="flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded-xl text-slate-600">
                                    <span>Gestor: <strong>${o.gestor}</strong></span>
                                    <span class="font-bold text-brand-blue">${veiculosAlocados.length} veículos alocados</span>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

            <!-- SESSÃO DE MOTORISTAS -->
            <div class="space-y-3 pt-3 border-t border-slate-200">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-base font-bold text-slate-800">Motoristas Responsáveis</h2>
                        <p class="text-xs text-slate-500">Condutores atribuídos por canteiro</p>
                    </div>
                    <button onclick="openModal('modal-novo-motorista')" class="bg-brand-blue hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                        <i class="fa-solid fa-user-plus"></i> Novo Motorista
                    </button>
                </div>

                <div class="space-y-2">
                    ${state.motoristas.map(m => {
                        const obra = state.obras.find(o => o.id === m.obraId);
                        return `
                            <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                                <div class="flex items-center space-x-3">
                                    <div class="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-sm">
                                        <i class="fa-solid fa-user-gear"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-bold text-slate-800 text-xs">${m.nome}</h4>
                                        <p class="text-[10px] text-slate-500">${m.cnh} • Tel: ${m.telefone}</p>
                                        <p class="text-[10px] text-brand-blue font-medium">Obra: ${obra ? obra.nome : 'Sem Alocação'}</p>
                                    </div>
                                </div>
                                <span class="text-[10px] bg-slate-100 font-mono px-2 py-1 rounded text-slate-600">CNH: ${m.cnhVencimento}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

        </div>
    `;
}

function handleSalvarObra(e) {
    e.preventDefault();
    const nome = document.getElementById('o-nome').value;
    const local = document.getElementById('o-local').value;
    const gestor = document.getElementById('o-gestor').value;
    const status = document.getElementById('o-status').value;

    state.obras.push({ id: state.obras.length + 1, nome, local, gestor, status });
    populateSelectOptions();
    closeModal('modal-nova-obra');
    showToast(`Obra "${nome}" cadastrada!`);
    render();
}

function handleSalvarMotorista(e) {
    e.preventDefault();
    const nome = document.getElementById('m-nome').value;
    const cnh = document.getElementById('m-cnh').value;
    const cnhVencimento = document.getElementById('m-vencimento').value;
    const obraId = parseInt(document.getElementById('m-obra').value);
    const telefone = document.getElementById('m-telefone').value;

    state.motoristas.push({ id: state.motoristas.length + 1, nome, cnh, cnhVencimento, obraId, telefone });
    populateSelectOptions();
    closeModal('modal-novo-motorista');
    showToast(`Motorista ${nome} cadastrado com sucesso!`);
    render();
}

// ==========================================
// 4. CONTROLE FINANCEIRO & DESPESAS (COMPLETO)
// ==========================================
function renderFinanceiro() {
    const filterTipo = state.selectedFilterFinancTipo;
    let list = state.financeiro;
    if(filterTipo !== 'todos') {
        list = state.financeiro.filter(f => f.tipo === filterTipo);
    }

    const totalGasto = state.financeiro.reduce((acc, f) => acc + f.valor, 0);

    return `
        <div class="space-y-4 animate-fade-in">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-base font-bold text-slate-800">Extrato Financeiro</h2>
                    <p class="text-xs text-slate-500">Lançamentos de combustível e despesas operacionais</p>
                </div>
                <button onclick="openModal('modal-financeiro')" class="bg-brand-green hover:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                    <i class="fa-solid fa-plus"></i> Lançar
                </button>
            </div>

            <!-- CARD RESUMO TOTAL -->
            <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold uppercase text-slate-400">Total de Despesas Registradas</span>
                    <p class="text-xl font-black text-slate-800">R$ ${totalGasto.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</p>
                </div>
                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-brand-green flex items-center justify-center font-bold text-lg">
                    <i class="fa-solid fa-receipt"></i>
                </div>
            </div>

            <!-- FILTRO POR TIPO -->
            <div class="flex space-x-2 overflow-x-auto no-scrollbar py-1">
                <button onclick="filterFinanceiro('todos')" class="px-3 py-1.5 ${filterTipo==='todos'?'bg-brand-navy text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Todos</button>
                <button onclick="filterFinanceiro('Combustível')" class="px-3 py-1.5 ${filterTipo==='Combustível'?'bg-brand-green text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Combustível</button>
                <button onclick="filterFinanceiro('Pedágio')" class="px-3 py-1.5 ${filterTipo==='Pedágio'?'bg-brand-blue text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Pedágio</button>
                <button onclick="filterFinanceiro('Peças / Insumos')" class="px-3 py-1.5 ${filterTipo==='Peças / Insumos'?'bg-indigo-600 text-white':'bg-white text-slate-600'} text-xs font-semibold rounded-xl border border-slate-200">Peças</button>
            </div>

            <!-- LISTA DE EXTRATO -->
            <div class="space-y-2.5">
                ${list.map(f => {
                    const veiculo = state.veiculos.find(v => v.id === f.veiculoId);
                    let icon = 'fa-gas-pump text-brand-green';
                    if(f.tipo === 'Pedágio') icon = 'fa-road text-brand-blue';
                    if(f.tipo === 'Peças / Insumos') icon = 'fa-gears text-indigo-600';

                    return `
                        <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center text-xs hover:border-slate-300 transition">
                            <div class="flex items-center space-x-3">
                                <div class="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-sm">
                                    <i class="fa-solid ${icon}"></i>
                                </div>
                                <div>
                                    <div class="flex items-center gap-1.5">
                                        <span class="font-bold text-slate-800">${f.tipo}</span>
                                        <span class="text-[10px] text-slate-400">• ${f.data}</span>
                                    </div>
                                    <p class="text-slate-500 text-[11px]">${veiculo ? veiculo.placa + ' - ' + veiculo.modelo : 'Veículo Desconhecido'}</p>
                                    <p class="text-[10px] text-slate-400">Condutor: ${f.motorista} ${f.litros > 0 ? '| ' + f.litros + ' Litros' : ''}</p>
                                </div>
                            </div>
                            <span class="font-extrabold text-slate-800 text-sm">R$ ${f.valor.toFixed(2)}</span>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function filterFinanceiro(tipo) {
    state.selectedFilterFinancTipo = tipo;
    render();
}

function toggleLitrosField() {
    const tipo = document.getElementById('f-tipo').value;
    const fieldLitros = document.getElementById('field-litros');
    if(tipo === 'Combustível') {
        fieldLitros.classList.remove('hidden');
    } else {
        fieldLitros.classList.add('hidden');
    }
}

function handleSalvarFinanceiro(e) {
    e.preventDefault();
    const tipo = document.getElementById('f-tipo').value;
    const veiculoId = parseInt(document.getElementById('f-veiculo').value);
    const valor = parseFloat(document.getElementById('f-valor').value);
    const litros = parseFloat(document.getElementById('f-litros').value || 0);
    const km = parseInt(document.getElementById('f-km').value);
    const data = document.getElementById('f-data').value;
    const motorista = document.getElementById('f-motorista').value;

    const veiculo = state.veiculos.find(v => v.id === veiculoId);

    state.financeiro.unshift({
        id: state.financeiro.length + 1,
        tipo, veiculoId, valor, litros, km, data, motorista, obraId: veiculo ? veiculo.obraId : 1
    });

    closeModal('modal-financeiro');
    showToast(`Despesa de R$ ${valor.toFixed(2)} registrada!`);
    render();
}

// ==========================================
// 5. MANUTENÇÕES
// ==========================================
function renderManutencao() {
    return `
        <div class="space-y-4 animate-fade-in">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-base font-bold text-slate-800">Oficina & Manutenções</h2>
                    <p class="text-xs text-slate-500">Controle preventivo e corretivo da frota</p>
                </div>
                <button onclick="openModal('modal-nova-manutencao')" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                    <i class="fa-solid fa-wrench"></i> Agendar
                </button>
            </div>

            <div class="space-y-3">
                ${state.manutencoes.map(m => {
                    const veiculo = state.veiculos.find(v => v.id === m.veiculoId);
                    let statusColor = 'bg-amber-100 text-amber-800';
                    if(m.status === 'Concluída') statusColor = 'bg-emerald-100 text-emerald-800';

                    return `
                        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2 text-xs">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="font-bold text-slate-800 text-sm block">${veiculo ? veiculo.placa + ' - ' + veiculo.modelo : 'Veículo'}</span>
                                    <span class="text-[10px] text-slate-400 font-medium">Tipo: ${m.tipo} • Agendado para: ${m.data}</span>
                                </div>
                                <span class="${statusColor} text-[10px] font-bold px-2.5 py-0.5 rounded-full">${m.status}</span>
                            </div>
                            <p class="text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">${m.descricao}</p>
                            <div class="flex justify-between items-center pt-1">
                                <span class="text-slate-400 text-[10px]">Custo Estimado</span>
                                <span class="font-black text-slate-800 text-sm">R$ ${m.custo.toFixed(2)}</span>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function handleSalvarManutencao(e) {
    e.preventDefault();
    const veiculoId = parseInt(document.getElementById('m-veiculo').value);
    const tipo = document.getElementById('m-tipo').value;
    const descricao = document.getElementById('m-descricao').value;
    const data = document.getElementById('m-data').value;
    const custo = parseFloat(document.getElementById('m-custo').value);
    const status = document.getElementById('m-status').value;

    state.manutencoes.unshift({
        id: state.manutencoes.length + 1,
        veiculoId, tipo, descricao, data, custo, status
    });

    // Atualiza status do veículo se estiver em manutenção
    if(status === 'Em Andamento') {
        const v = state.veiculos.find(x => x.id === veiculoId);
        if(v) v.status = 'Manutenção';
    }

    closeModal('modal-nova-manutencao');
    showToast('Manutenção registrada com sucesso!');
    render();
}

// ==========================================
// 6. CANHOTOS & DOCUMENTAÇÃO
// ==========================================
function renderDocumentos() {
    return `
        <div class="space-y-5 animate-fade-in">

            <!-- CANHOTOS -->
            <div class="space-y-3">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-base font-bold text-slate-800">Canhotos & Comprovantes</h2>
                        <p class="text-xs text-slate-500">Termos de entrega, devolução e vistorias</p>
                    </div>
                    <button onclick="openModal('modal-canhoto')" class="bg-brand-blue hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5">
                        <i class="fa-solid fa-file-arrow-up"></i> Anexar
                    </button>
                </div>

                <div class="space-y-2">
                    ${state.canhotos.map(c => {
                        const veiculo = state.veiculos.find(v => v.id === c.veiculoId);
                        return `
                            <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center text-xs">
                                <div class="flex items-center space-x-3">
                                    <div class="w-9 h-9 rounded-xl bg-blue-50 text-brand-blue flex items-center justify-center font-bold text-sm">
                                        <i class="fa-solid fa-file-lines"></i>
                                    </div>
                                    <div>
                                        <p class="font-bold text-slate-800">${c.tipo}</p>
                                        <p class="text-slate-400 text-[10px]">${veiculo ? veiculo.placa + ' - ' + veiculo.modelo : ''} • Data: ${c.data}</p>
                                        <p class="text-[10px] text-slate-500 italic mt-0.5">${c.obs || ''}</p>
                                    </div>
                                </div>
                                <span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">${c.status}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

            <!-- REGULARIDADE DE DOCUMENTOS -->
            <div class="space-y-3 pt-3 border-t border-slate-200">
                <h2 class="text-base font-bold text-slate-800">Regularidade de Documentação</h2>
                <div class="space-y-2">
                    ${state.documentosRegulação.map(d => {
                        let badge = 'bg-emerald-100 text-emerald-800';
                        if(d.status === 'Atencao') badge = 'bg-amber-100 text-amber-800';
                        if(d.status === 'Vencido') badge = 'bg-red-100 text-red-800';

                        return `
                            <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between text-xs">
                                <div>
                                    <p class="font-bold text-slate-800">${d.titulo}</p>
                                    <p class="text-[10px] text-slate-400">Vencimento: ${d.vencimento}</p>
                                </div>
                                <span class="${badge} text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase">${d.status}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

        </div>
    `;
}

function handleSalvarCanhoto(e) {
    e.preventDefault();
    const veiculoId = parseInt(document.getElementById('c-veiculo').value);
    const tipo = document.getElementById('c-tipo').value;
    const obs = document.getElementById('c-obs').value;

    state.canhotos.unshift({
        id: state.canhotos.length + 1,
        veiculoId, tipo, obs, data: new Date().toISOString().split('T')[0], status: 'Aprovado'
    });

    closeModal('modal-canhoto');
    showToast('Canhoto anexado com sucesso!');
    render();
}

// ==========================================
// 7. RELATÓRIOS & INTELIGÊNCIA DE BI
// ==========================================
function renderRelatorios() {
    return `
        <div class="space-y-5 animate-fade-in">

            <div>
                <h2 class="text-base font-bold text-slate-800 flex items-center gap-2">
                    <i class="fa-solid fa-chart-line text-brand-blue"></i> Central BI & Relatórios Customizados
                </h2>
                <p class="text-xs text-slate-500">Métricas consolidadas de custos, combustível e faturamento</p>
            </div>

            <!-- GERADOR CUSTOMIZADO -->
            <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider border-b border-slate-100 pb-2">
                    <i class="fa-solid fa-sliders text-brand-green"></i> Gerador de Relatório
                </h3>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Tipo de Relatório</label>
                        <select id="rep-tipo" onchange="atualizarPreviewRelatorio()" class="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 outline-none">
                            <option value="custo-obra">Resumo Financeiro por Obra</option>
                            <option value="frota">Status Completo da Frota</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Filtrar por Obra</label>
                        <select id="rep-obra" onchange="atualizarPreviewRelatorio()" class="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 outline-none">
                            <option value="todas">Todas as Obras</option>
                            ${state.obras.map(o => `<option value="${o.id}">${o.nome}</option>`).join('')}
                        </select>
                    </div>
                </div>

                <!-- EXPORTAR -->
                <div class="flex gap-2 pt-1">
                    <button onclick="exportarRelatorio('pdf')" class="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center justify-center gap-1.5">
                        <i class="fa-solid fa-file-pdf"></i> Imprimir / PDF
                    </button>
                    <button onclick="exportarRelatorio('excel')" class="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center justify-center gap-1.5">
                        <i class="fa-solid fa-file-excel"></i> Exportar Excel
                    </button>
                </div>
            </div>

            <!-- GRÁFICOS DINÂMICOS CHART.JS -->
            <div class="grid grid-cols-1 gap-4">
                <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                    <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider">Custos Mensais por Obra (R$)</h3>
                    <div class="h-56 relative">
                        <canvas id="chartCustosObra"></canvas>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                    <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider">Consumo de Combustível (Litros/Mês)</h3>
                    <div class="h-56 relative">
                        <canvas id="chartConsumoMes"></canvas>
                    </div>
                </div>
            </div>

            <!-- TABELA PREVIEW -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-4 space-y-2">
                <h3 class="text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2">Preview Consolidado</h3>
                <div id="relatorio-preview-table" class="overflow-x-auto"></div>
            </div>

        </div>
    `;
}

function initBICharts() {
    const ctx1 = document.getElementById('chartCustosObra');
    if(ctx1) {
        if(chartCustosObra) chartCustosObra.destroy();
        chartCustosObra = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: state.obras.map(o => o.nome),
                datasets: [
                    {
                        label: 'Locação (R$)',
                        data: state.obras.map(o => state.veiculos.filter(v=>v.obraId===o.id).reduce((a,v)=>a+v.valorMensal,0)),
                        backgroundColor: '#2563EB'
                    },
                    {
                        label: 'Despesas (R$)',
                        data: state.obras.map(o => state.financeiro.filter(f=>f.obraId===o.id).reduce((a,f)=>a+f.valor,0)),
                        backgroundColor: '#10B981'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { font: { size: 10 } } } }
            }
        });
    }

    const ctx2 = document.getElementById('chartConsumoMes');
    if(ctx2) {
        if(chartConsumoMes) chartConsumoMes.destroy();
        chartConsumoMes = new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['Jul', 'Ago', 'Set', 'Out'],
                datasets: [{
                    label: 'Litros Consumidos',
                    data: [280, 390, 340, 365],
                    borderColor: '#059669',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { font: { size: 10 } } } }
            }
        });
    }

    atualizarPreviewRelatorio();
}

function atualizarPreviewRelatorio() {
    const container = document.getElementById('relatorio-preview-table');
    if(!container) return;

    const tipo = document.getElementById('rep-tipo')?.value || 'custo-obra';

    if(tipo === 'custo-obra') {
        container.innerHTML = `
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="bg-slate-50 text-slate-500 border-b border-slate-200">
                        <th class="p-2">Obra</th>
                        <th class="p-2">Veículos</th>
                        <th class="p-2">Locação Mensal</th>
                        <th class="p-2">Despesas Lançadas</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    ${state.obras.map(o => {
                        const veics = state.veiculos.filter(v => v.obraId === o.id);
                        const loc = veics.reduce((a,v)=>a+v.valorMensal, 0);
                        const desp = state.financeiro.filter(f=>f.obraId===o.id).reduce((a,f)=>a+f.valor, 0);
                        return `
                            <tr>
                                <td class="p-2 font-bold text-slate-800">${o.nome}</td>
                                <td class="p-2">${veics.length} un.</td>
                                <td class="p-2 font-semibold">R$ ${loc.toLocaleString('pt-BR')}</td>
                                <td class="p-2 text-emerald-700 font-semibold">R$ ${desp.toLocaleString('pt-BR')}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
    } else {
        container.innerHTML = `
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="bg-slate-50 text-slate-500 border-b border-slate-200">
                        <th class="p-2">Placa / Modelo</th>
                        <th class="p-2">Status</th>
                        <th class="p-2">Hodômetro</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    ${state.veiculos.map(v => `
                        <tr>
                            <td class="p-2 font-bold">${v.placa} - ${v.modelo}</td>
                            <td class="p-2">${v.status}</td>
                            <td class="p-2 font-mono">${v.km.toLocaleString()} KM</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }
}

function exportarRelatorio(formato) {
    if(formato === 'pdf') {
        window.print();
    } else {
        showToast('Relatório exportado para Excel (.xlsx) com sucesso!');
    }
}

// ==========================================
// UTILS, MODAIS & TOAST
// ==========================================
function openModal(id) {
    populateSelectOptions();
    document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

function renderNotificacoesModal() {
    const container = document.getElementById('lista-notificacoes');
    if(!container) return;
    container.innerHTML = `
        <div class="p-3 bg-red-50 border border-red-100 rounded-xl text-xs space-y-1">
            <p class="font-bold text-red-800"><i class="fa-solid fa-circle-exclamation"></i> Licenciamento Vencido</p>
            <p class="text-slate-600">Mercedes Atego (RST-5A12)</p>
        </div>
        <div class="p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs space-y-1">
            <p class="font-bold text-amber-800"><i class="fa-solid fa-clock"></i> Revisão Próxima</p>
            <p class="text-slate-600">Cat Retroescavadeira aos 3.300h</p>
        </div>
    `;
}

function simularUploadFoto() {
    const preview = document.getElementById('file-upload-preview');
    if(preview) preview.classList.remove('hidden');
}

function showToast(message) {
    const container = document.getElementById('toast-container');
    if(!container) return;
    const toast = document.createElement('div');
    toast.className = 'bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl text-xs font-semibold flex items-center gap-2 border border-slate-700 animate-fade-in';
    toast.innerHTML = `<i class="fa-solid fa-circle-check text-brand-emerald"></i> ${message}`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
